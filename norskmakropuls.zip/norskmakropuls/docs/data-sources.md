# Datakilder og lisenser

Dette dokumentet beskriver hver datakilde norskmakropuls bruker, hvordan
data hentes, og hvilken lisens som gjelder. For maskinlesbar oversikt,
se `data_catalog.yaml`.

## SSB Statistikkbanken

**API**: PxWebApi (JSON-stat2)
**Endepunkt**: https://data.ssb.no/api/v0/no/table/{table_id}
**Lisens**: NLOD 2.0 (Norsk lisens for offentlige data)
**Krav**: Tydelig kildehenvisning ("Kilde: SSB"). Ingen forvanskning av
data eller fremstilling som kan skape forveksling med offisielle SSB-
publikasjoner.
**API-nøkkel**: Ikke nødvendig for offentlige tabeller.
**Rate limit**: Ikke dokumentert eksplisitt; praksis tilsier lav frekvens.
**Vintage-håndtering**: SSB publiserer reviderte serier; vintage_id i vår
lagring fanger dette.

Tabeller brukt i MVP: 09190, 03013, 05327, 08517, 11417, 07230, 10945,
05111 (sistnevnte for NAV-data).

## Norges Bank Data

**API**: SDMX-JSON
**Endepunkt**: https://data.norges-bank.no/api/data/{flow}/{key}
**Lisens**: Norges Banks vilkår for bruk av data — fri bruk forutsatt
kildehenvisning.
**Krav**: Kildehenvisning ("Kilde: Norges Bank"). Banken garanterer ikke
for kontinuitet i serier som omklassifiseres.
**API-nøkkel**: Ikke nødvendig.
**Rate limit**: Ikke dokumentert.
**Vintage-håndtering**: Daglige serier resamples til månedssnitt for
makro-formål; rådata beholdes uendret i `data/raw/`.

Dataflows brukt i MVP: SHORT_RATES (styringsrenten), EXR (valutakurser).

## FRED (Federal Reserve Economic Data)

**API**: CSV (fredgraph.csv-endepunktet)
**Endepunkt**: https://fred.stlouisfed.org/graph/fredgraph.csv?id={series_id}
**Lisens**: Public domain for de fleste serier; enkelte tredjepartsserier
har egne vilkår (oppgis ved henting).
**Krav**: Anbefalt kildehenvisning til både FRED og opphavlig kilde
(f.eks. "U.S. Energy Information Administration via FRED").
**API-nøkkel**: Ikke nødvendig for CSV-endepunktet (er nødvendig for det
strukturerte JSON-API-et, som vi ikke bruker).
**Rate limit**: 120 requests/min for CSV-endepunktet.
**Manglende observasjoner**: FRED bruker `.` for missing values; vår
parser konverterer disse til NaN.

Serier brukt i MVP: DCOILBRENTEU (Brent), ECBDFR (ECB innskuddsrente),
CLVMNACSCAB1GQEA19 (eurosone-BNP). Flere serier (DGS10, DGS2, FEDFUNDS,
CPIAUCSL) legges til i Fase 1.

## NAV (via SSB)

**Bakgrunn**: NAV publiserer registrert ledighet via egen statistikkside,
men deres egne åpne API-er har vist seg ustabile for vår bruk. Samme tall
publiseres i SSB tabell 05111 med ca. ett døgns lag, og vi henter dem
derfra for bedre stabilitet.
**Lisens**: NLOD 2.0 (samme som SSB).
**Krav**: Kildehenvisning ("Kilde: NAV via SSB").

## Datakilder som er vurdert og avvist for MVP

| Kilde | Begrunnelse |
|---|---|
| Norges Bank MPR-XLSX | Sårbar for strukturendringer; defensiv parser planlagt for Fase 4. |
| Eiendom Norge | Lisensavklaring kreves før produksjon. |
| PMI (Norge) | Ikke åpent maskinlesbart format. |
| Consensus Economics | Betalt tjeneste; ikke aktuelt for åpent prosjekt. |
| IEA / EIA energidata | Lisensvurdering pågår; ikke i MVP. |
| Nord Pool kraftpriser | Lisensavklaring kreves. |
| Finansdepartementets prognoser | Skal ikke være kritisk feed. Vurderes som tilleggsanker i senere fase. |

## Generelle krav i dette prosjektet

- Alle observasjoner lagres med vintage-tidsstempel.
- Tabell-IDer og series keys hardkodes ikke spredt i koden — de leses fra
  `data_catalog.yaml`.
- Ingen kilde går til produksjon uten å være klassifisert (`A_PROD`,
  `B_TEST`, `C_FALLBACK`, eller `D_EXCLUDE` for ekskluderte).
- Ved skjemabrudd skal pipeline feile kontrollert (raise `ValueError`),
  ikke stille.
