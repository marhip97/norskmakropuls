# Status

Sist oppdatert: 2026-04-29

Dette dokumentet beskriver hvor prosjektet er **akkurat nå**. Det skal kunne leses på under ett minutt før hver arbeidsøkt og oppdateres etter hver økt der noe vesentlig endres.

---

## Nåværende fase

**Fase 0 — Repo-oppsett**, går over i **Fase 1 — Datakatalog og kildeutvidelse** så snart første pipeline-kjøring er verifisert.

norskmakropuls er etterfølger til SMART-repoet og arver datalaget, testene og CI/CD-mønstrene derfra. Selve datakildene må verifiseres på nytt i dette repoet (første pipeline-kjøring), siden `data/raw/` er tom ved oppstart.

## Hva er gjort

**Repo-oppsett:**
- [x] Mappestruktur opprettet (se `PROJECT_PLAN.md` seksjon 11)
- [x] Datalaget hentet fra SMART (`src/data/`)
- [x] Tester for datalaget hentet fra SMART (`tests/`)
- [x] CI/CD-workflows hentet og tilpasset
- [x] `requirements.txt`, `requirements-dev.txt`, `.gitignore`, `LICENSE` på plass
- [x] `PROJECT_PLAN.md`, `STATUS.md`, `CLAUDE.md` opprettet

**Konfigurasjon:**
- [x] `config/variables.yaml` med 12 variabler arvet fra SMART
- [x] Skjelett for `data_catalog.yaml` opprettet (må fylles i Fase 1)

## Hva er under arbeid

Ingenting aktivt. Venter på første pipeline-kjøring i nytt repo for å bekrefte at datalaget fungerer her som det gjorde i SMART.

## Hva står for tur

Prioritert rekkefølge for Fase 1:

1. **Verifiser pipeline i nytt repo:** kjør `python -m src.data.pipeline` lokalt eller via GitHub Actions. Forventet utfall: 12/12 variabler hentes uten feil, ny vintage lagres i `data/raw/`.
2. **Fyll `data_catalog.yaml`** med de 12 eksisterende variablene. Dette er en ny artefakt SMART ikke hadde — alle tabell-ID-er, series keys og filtre samles maskinlesbart ett sted.
3. **Discovery for nye Norges Bank-serier:** `usd_nok`, `i44`, `nowa`, `gov_yield_2y_no`, `gov_yield_10y_no`. Bruk `scripts/discover_api.py`.
4. **Implementer FRED-utvidelser:** `us_10y_yield`, `us_2y_yield`, `fed_funds`, `us_cpi`. Eksisterende klient håndterer alt; bare YAML-oppføring trengs.
5. **Skriv `docs/data_source_validation_report.md`** basert på funnene.

Etter Fase 1 starter Fase 2 (ankerbane-infrastruktur). Se `PROJECT_PLAN.md` for full faseplan.

## Blokkeringer og åpne spørsmål

| Spørsmål | Status | Hvem avgjør |
|---|---|---|
| Skal SMART-repoet arkiveres (read-only) når norskmakropuls tar over? | Åpent | Prosjekteier |
| MPR-XLSX-parser i fase 2 eller fase 4? | Anbefalt: fase 4. Manuelle innlastninger som fallback i fase 2 | Bekreftes etter første test |
| SSB Konjunkturtendensene: HTML-parser eller manuell? | Anbefalt: manuell først | Bekreftes i fase 2 |
| Hvilken GitHub Pages-URL skal det nye dashboardet ha? | Åpent (forslag: marhip97.github.io/norskmakropuls eller egen domene) | Prosjekteier |

## Datakildestatus

Statusen under er **planlagt basert på SMART-erfaring**. Den oppdateres til "Verifisert i norskmakropuls" etter første pipeline-kjøring i nytt repo.

| Kilde | Variabel | Forventet status | Faktisk status | Sist verifisert |
|---|---|---|---|---|
| SSB 09190 | `bnp_fastland` | A_PROD | Ikke verifisert | — |
| SSB 03013 | `kpi` | A_PROD | Ikke verifisert | — |
| SSB 05327 | `kpi_jae` | A_PROD | Ikke verifisert | — |
| SSB 05111 | `ledighet_aku` | A_PROD | Ikke verifisert | — |
| SSB 11417 | `lonnsvekst` | A_PROD | Ikke verifisert | — |
| SSB 07230 | `boligprisvekst` | A_PROD | Ikke verifisert | — |
| SSB 11599 | `k2_kredittvekst` | A_PROD | Ikke verifisert | — |
| Norges Bank SHORT_RATES | `styringsrente` | A_PROD_WITH_CAVEAT | Ikke verifisert | — |
| Norges Bank EXR | `eurnok` | A_PROD | Ikke verifisert | — |
| FRED DCOILBRENTEU | `oljepris` | A_PROD | Ikke verifisert | — |
| FRED ECBDFR | `ecb_rente` | A_PROD | Ikke verifisert | — |
| FRED CLVMNACSCAB1GQEA19 | `handelspartnervekst` | A_PROD | Ikke verifisert | — |

**Variabler som skal legges til i Fase 1:**

| Kilde | Variabel | Status |
|---|---|---|
| Norges Bank | `usd_nok` | B_VERIFY (discovery kreves) |
| Norges Bank | `i44` | B_VERIFY (discovery kreves) |
| Norges Bank | `nowa` | B_VERIFY (discovery kreves) |
| Norges Bank | `gov_yield_2y_no` | B_VERIFY (discovery kreves) |
| Norges Bank | `gov_yield_10y_no` | B_VERIFY (discovery kreves) |
| FRED | `us_10y_yield` (DGS10) | A_PROD_TEST_FETCH |
| FRED | `us_2y_yield` (DGS2) | A_PROD_TEST_FETCH |
| FRED | `fed_funds` (FEDFUNDS) | A_PROD_TEST_FETCH |
| FRED | `us_cpi` (CPIAUCSL) | A_PROD_TEST_FETCH |

## Pipelinestatus

Ingen kjøringer ennå i dette repoet. Første kjøring planlegges manuelt via `workflow_dispatch` i `.github/workflows/data_pipeline.yml` for å verifisere at alt fungerer før den ukentlige cron'en aktiveres.

## Ankerbane-status

Ikke startet. Modulen `src/anchors/` finnes som tom mappe med en README som beskriver design. Implementering starter i Fase 2.

## News-motor-status

Ikke startet. Modulen `src/news/` finnes som tom mappe. Implementering starter i Fase 2 etter ankerbane.

## Modellstatus

SMART-modellene (ARIMA, VAR, BVAR, DFM, AR-X, ML-baseline) er **ikke** kopiert inn i norskmakropuls ennå. De hentes inn i Fase 5 og knyttes opp som kryssjekk mot ankerbanen. Inntil da bor de fortsatt i SMART-repoet.

Nye revisjonsmodeller som skal bygges i Fase 3:

- `src/models/shadow_rate.py` (skyggerentebane)
- `src/models/inflation_components.py` (komponentmodell for inflasjon)
- `src/models/nav_to_aku.py` (NAV-til-AKU bro)

## Frontend-status

Ikke startet. Mappen `dashboard-aksel/` finnes med en README som beskriver Next.js + Aksel-oppsettet. Implementering starter i Fase 4.

## Tekniske beslutninger så langt

| Beslutning | Begrunnelse | Dato |
|---|---|---|
| Etterfølger til SMART, nytt repo | Klart skille mellom gammelt og nytt produkt; lettere kommunikasjon utad | 2026-04-29 |
| Hent datalaget uendret fra SMART | Datalaget er modent og verdifullt; ingen grunn til å skrive om | 2026-04-29 |
| Hent ikke SMART-modeller før Fase 5 | Holder repoet rent og fokusert mens ankerbanen bygges | 2026-04-29 |
| `data_catalog.yaml` som førsterangs kildekatalog | Ny artefakt SMART manglet; sentralt sted for tabell-ID-er og series keys | 2026-04-29 |
| Aksel/NAV som designsystem | Gir nøkternt, tilgjengelig, offentlig egnet preg | 2026-04-29 (arvet fra SMART) |
| SSB Statbank som ryggrad | Mest stabil og dokumentert kilde for norsk makro | 2026-04-29 (arvet fra SMART) |
| Norsk språk i grensesnittet (bokmål) | Målgruppen er norsk | 2026-04-29 (arvet fra SMART) |

## Endringslogg

| Dato | Endring | Av |
|---|---|---|
| 2026-04-29 | Initiell oppretting av norskmakropuls. Datalag hentet fra SMART-repoet. | Plan-fase |

---

## Hvordan oppdatere dette dokumentet

Etter hver arbeidsøkt der noe vesentlig endres:

1. Oppdater "Sist oppdatert"-dato øverst.
2. Flytt avhukede oppgaver fra "Under arbeid" til "Hva er gjort".
3. Legg nye oppgaver i "Hva står for tur".
4. Oppdater datakildestatus-tabellen ved verifisering.
5. Logg viktige beslutninger i tabellen "Tekniske beslutninger så langt".
6. Skriv én linje i endringsloggen.

Hold dokumentet kort. Detaljer hører hjemme i `docs/SPEC.md` eller i commit-meldinger.
