# dashboard-aksel/

Next.js + Aksel frontend for norskmakropuls. Implementeres i Fase 4.

## Teknologivalg

- **Next.js** med statisk eksport (`next export`) for deploy til GitHub Pages
- **@navikt/ds-react** v7 for komponenter (Button, Heading, Modal, Tabs, ...)
- **@navikt/ds-css** for grunnleggende styling
- **@navikt/ds-tokens** for designtokens (farger, typografi, spacing)
- **@navikt/aksel-icons** for ikoner
- **Plotly** eller **Recharts** for grafer (besluttes i Fase 4)
- **TypeScript** gjennom hele

Aksel-systemet bruker `data-color`-attributter for fargevariasjon (det
nye "darkside"-systemet). Dokumentasjon: https://aksel.nav.no

## Sider

- `/` Makropuls (oversiktsside med variabelkort)
- `/rente` Rente og finansielle forhold
- `/inflasjon` Inflasjon (KPI, KPI-JAE, komponenter)
- `/arbeidsmarked` Arbeidsmarked (AKU, NAV, lønnsvekst)
- `/aktivitet` Aktivitet (BNP, indikatorer)
- `/prognoser` Prognoser med ankerbane og kryssjekk
- `/datakvalitet` Datakvalitet og metode

## Datatilgang

Frontenden leser ferdiglagde JSON-filer fra `public/data/` som bygges
av `src/dashboard/cache_builder.py` på pipeline-kjøring. Ingen API-kall
kjøres fra frontenden — alt er statisk ved deploy.

## Initiert med

```bash
npx create-next-app@latest dashboard-aksel --typescript --eslint --app
cd dashboard-aksel
npm install @navikt/ds-react @navikt/ds-css @navikt/ds-tokens @navikt/aksel-icons
```

## Deploy

GitHub Actions workflow `.github/workflows/deploy_dashboard.yml`
(legges til i Fase 4) kjører `next build && next export` og publiserer
til GitHub Pages.

## Status

Ikke startet. Mappen er reservert.
