"""Discovery helper for SSB tables and Norges Bank dataflows.

Gir et raskt CLI for å søke i SSB sin tabellkatalog og inspisere
Norges Bank-dataflows før man legger til en variabel i variables.yaml.

Eksempler:
    python -m scripts.discover_api --search "konsumpris"
    python -m scripts.discover_api --ssb-table 03013
    python -m scripts.discover_api --nb-flow EXR
"""

from __future__ import annotations

import argparse
import sys

import requests

SSB_TABLE_SEARCH = "https://data.ssb.no/api/v0/no/table"
NB_BASE = "https://data.norges-bank.no/api/data"


def search_ssb(keyword: str, max_results: int = 20) -> None:
    """Search SSB tables by keyword (uses the public table catalogue)."""
    url = f"https://data.ssb.no/api/v0/no/table?lang=no&query={keyword}"
    print(f"Searching SSB tables for '{keyword}'...")
    print(f"Open in browser: {url}")
    print("(SSB does not expose a public JSON keyword search; use the catalog UI:")
    print("  https://www.ssb.no/statbank )")
    print()
    print("Once you have a table number, inspect it with:")
    print(f"  python -m src.data.discover_api --table <id>")


def inspect_nb_flow(flow: str) -> None:
    """Fetch a small slice of a Norges Bank dataflow to see series structure."""
    url = f"{NB_BASE}/{flow}"
    params = {"format": "sdmx-json", "lastNObservations": 1, "locale": "no"}
    print(f"Fetching Norges Bank dataflow '{flow}'...")
    resp = requests.get(url, params=params, timeout=30)
    resp.raise_for_status()
    data = resp.json()

    structure = data.get("data", {}).get("structure", {})
    series_dims = structure.get("dimensions", {}).get("series", [])

    print(f"\nDataflow: {flow}")
    print("=" * 70)
    print("Series dimensions:")
    for dim in series_dims:
        dim_id = dim["id"]
        values = dim.get("values", [])
        print(f"\n  {dim_id} ({dim.get('name', '')}): {len(values)} values")
        for v in values[:25]:
            label = v.get("name", "")
            print(f"    {v['id']:<15} {label}")
        if len(values) > 25:
            print(f"    ... ({len(values) - 25} more)")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Discover SSB tables and Norges Bank series before adding to variables.yaml.",
    )
    parser.add_argument("--search", help="SSB table keyword search (opens UI hint)")
    parser.add_argument("--ssb-table", help="Inspect an SSB table by number")
    parser.add_argument("--nb-flow", help="Inspect a Norges Bank dataflow (e.g. EXR, SHORT_RATES)")
    args = parser.parse_args()

    if not any([args.search, args.ssb_table, args.nb_flow]):
        parser.print_help()
        sys.exit(0)

    if args.search:
        search_ssb(args.search)

    if args.ssb_table:
        from src.data.discover_api import inspect_table
        inspect_table(args.ssb_table)

    if args.nb_flow:
        inspect_nb_flow(args.nb_flow)


if __name__ == "__main__":
    main()
