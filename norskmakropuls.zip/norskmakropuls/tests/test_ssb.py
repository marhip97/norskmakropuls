"""Tester for SSBDataSource (mockede HTTP-kall)."""

from __future__ import annotations

import pandas as pd
import pytest
import responses

from src.data.ssb import SSBDataSource, _parse_jsonstat2, _parse_ssb_date


# --- Date parser ----------------------------------------------------------------

def test_parse_ssb_date_quarterly():
    assert _parse_ssb_date("2023K2") == pd.Timestamp("2023-04-01")


def test_parse_ssb_date_monthly():
    assert _parse_ssb_date("2023M07") == pd.Timestamp("2023-07-01")


def test_parse_ssb_date_annual():
    assert _parse_ssb_date("2023") == pd.Timestamp("2023-01-01")


def test_parse_ssb_date_invalid():
    assert _parse_ssb_date("garbage") is None


# --- JSON-stat2 parser ----------------------------------------------------------

def _example_jsonstat2():
    """Et minimalt men gyldig JSON-stat2-svar med tre måneder."""
    return {
        "id": ["Konsumgrp", "ContentsCode", "Tid"],
        "size": [1, 1, 3],
        "value": [3.4, 3.5, 3.6],
        "dimension": {
            "Konsumgrp": {"category": {"index": {"TOTAL": 0}}},
            "ContentsCode": {"category": {"index": {"TolvmanedersR": 0}}},
            "Tid": {
                "category": {
                    "index": {"2024M01": 0, "2024M02": 1, "2024M03": 2},
                }
            },
        },
    }


def test_parse_jsonstat2_basic():
    df = _parse_jsonstat2(_example_jsonstat2())
    assert list(df.columns) == ["date", "value"]
    assert len(df) == 3
    assert df["value"].tolist() == [3.4, 3.5, 3.6]
    assert df["date"].iloc[0] == pd.Timestamp("2024-01-01")


# --- SSBDataSource end-to-end (mocked) ------------------------------------------

@responses.activate
def test_ssb_datasource_fetch_validates_filters(reset_ssb_metadata_cache):
    """Verifiserer at filter valideres mot metadata før query sendes."""
    metadata = {
        "title": "Test table",
        "variables": [
            {"code": "Konsumgrp", "values": ["TOTAL", "FOOD"]},
            {"code": "ContentsCode", "values": ["TolvmanedersR"]},
            {"code": "Tid", "values": ["2024M01"]},
        ],
    }
    responses.add(
        responses.GET,
        "https://data.ssb.no/api/v0/no/table/03013",
        json=metadata,
    )
    responses.add(
        responses.POST,
        "https://data.ssb.no/api/v0/no/table/03013",
        json=_example_jsonstat2(),
    )

    src = SSBDataSource(
        variable_id="kpi",
        source_params={
            "table_id": "03013",
            "filters": {
                "Konsumgrp": ["TOTAL"],
                "ContentsCode": ["TolvmanedersR"],
                "Tid": ["*"],
            },
        },
    )
    df = src.fetch()
    assert len(df) == 3


@responses.activate
def test_ssb_datasource_rejects_invalid_dimension(reset_ssb_metadata_cache):
    """Hvis bruker oppgir ukjent dimensjon, skal validate_filters feile."""
    responses.add(
        responses.GET,
        "https://data.ssb.no/api/v0/no/table/03013",
        json={
            "title": "Test",
            "variables": [{"code": "Konsumgrp", "values": ["TOTAL"]}],
        },
    )
    src = SSBDataSource(
        variable_id="kpi",
        source_params={
            "table_id": "03013",
            "filters": {"BogusDim": ["X"]},
        },
    )
    with pytest.raises(ValueError, match="dimension 'BogusDim' not found"):
        src.fetch()
