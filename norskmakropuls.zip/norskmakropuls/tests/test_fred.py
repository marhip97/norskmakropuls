"""Tester for FREDDataSource."""

from __future__ import annotations

import pytest
import responses

from src.data.fred import FREDDataSource


_FRED_CSV = """DATE,DCOILBRENTEU
2024-01-02,75.50
2024-01-03,76.20
2024-01-04,.
2024-01-05,77.10
"""


@responses.activate
def test_fred_fetch_handles_dot_as_nan():
    """FRED bruker '.' for manglende observasjoner; disse skal bli NaN."""
    responses.add(
        responses.GET,
        "https://fred.stlouisfed.org/graph/fredgraph.csv",
        body=_FRED_CSV,
        content_type="text/csv",
    )
    src = FREDDataSource(
        variable_id="oljepris",
        source_params={"series_id": "DCOILBRENTEU"},
    )
    df = src.fetch()
    # 3 valid observations + 1 NaN-row
    assert len(df) == 4
    # Row 3 (date 2024-01-04) should have NaN value
    nan_count = df["value"].isna().sum()
    assert nan_count == 1


@responses.activate
def test_fred_validate_rejects_excessive_nulls():
    csv = "DATE,X\n2024-01-01,.\n2024-01-02,.\n2024-01-03,.\n2024-01-04,1.0\n"
    responses.add(
        responses.GET,
        "https://fred.stlouisfed.org/graph/fredgraph.csv",
        body=csv,
        content_type="text/csv",
    )
    src = FREDDataSource(
        variable_id="x",
        source_params={"series_id": "X"},
    )
    df = src.fetch()
    with pytest.raises(ValueError, match="null values"):
        src.validate(df)
