# norskmakropuls

Et automatisert, forklarbart dashboard som viser et oppdatert situasjonsbilde av norsk økonomi og anslag for de neste 1–3 årene. Dashboardet bruker offisielle prognoser fra Norges Bank og SSB som anker, og oppdaterer vurderingen løpende med ny statistikk.

> **Merk:** norskmakropuls er et eksperimentelt analyseverktøy. Prognosene er ikke offisielle og skal ikke brukes som grunnlag for investerings- eller policybeslutninger.

## Hva prosjektet svarer på

> Hvordan ser det norske makrobildet trolig ut i dag, gitt all ny informasjon publisert siden siste offisielle prognoserunde?

Hovedlogikken:

```
Oppdatert anslag = siste offisielle anslag + modellert revisjon fra nye data
```

## Status

Tidlig i utvikling. Datalaget er på plass og henter 12 variabler ukentlig fra SSB, Norges Bank og FRED. Ankerbane-modulen, news-motoren og Aksel-frontenden er under planlegging.

Se [`STATUS.md`](STATUS.md) for løpende fremdrift og [`PROJECT_PLAN.md`](PROJECT_PLAN.md) for strategisk retning.

## Bakgrunn

norskmakropuls er etterfølgeren til prosjektet SMART (System for Model Analysis in Real Time), et kryssjekkrammeverk der flere uavhengige modeller produserte parallelle prognoser. Datalaget, testene og infrastrukturen er gjenbrukt fra SMART; produktprinsippet og frontenden er nytt. Se `PROJECT_PLAN.md` seksjon 0 for begrunnelse.

## Kom i gang

```bash
pip install -r requirements-dev.txt
pytest tests/

python -m src.data.pipeline                  # hent alle variabler
python -m src.data.pipeline kpi bnp_fastland  # hent spesifikke variabler
```

For å oppdage nye SSB-tabeller eller Norges Bank-serier:

```bash
python -m scripts.discover_api --search "konsumpris"
python -m src.data.discover_api --table 09190
```

## Repo-struktur

```
config/             variabel- og modellkonfigurasjon
data_catalog.yaml   maskinlesbar oversikt over alle datakilder
src/data/           datapipeline (kildeklienter, validering, lagring)
src/anchors/        ankerprognose-håndtering (under bygging)
src/news/           news-motor (under bygging)
src/models/         revisjonsmodeller (under bygging)
tests/              enhets- og integrasjonstester
docs/               dokumentasjon og beslutningslogg
dashboard-aksel/    Next.js + Aksel frontend (under bygging)
data/raw/           rådata med vintage-tidsstempler
data/anchors/       lagrede ankerprognoser med vintage
.github/workflows/  CI/CD og automatisk pipeline
```

## Datakilder

| Kilde | Hva | Lisens |
|---|---|---|
| SSB Statistikkbanken | BNP, KPI, KPI-JAE, AKU-ledighet, lønnsvekst, boligprisvekst, K2 | NLOD 2.0 |
| Norges Bank Data | Styringsrente, EUR/NOK | CC BY 4.0-kompatibel |
| FRED | Oljepris (Brent), ECB-rente, USA-renter, USA KPI | Offentlig tilgjengelig |

Detaljer i `docs/data-sources.md`.

## Lisens

MIT License – se `LICENSE`.
